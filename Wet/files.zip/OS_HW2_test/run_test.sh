#!/bin/sh

g++ -g ./hw2_test.cxx -o hw2_test -lrt
./hw2_test
